package th_b84.SpringTrainJDBC;

public interface CRUDOperations {
	
	public void insert(Book book);

}
